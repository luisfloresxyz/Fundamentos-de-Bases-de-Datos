Jaime Daniel Garc�a Argueta 312104739
Flores Gonz�lez Luis Brandon 312218342
P�rez Villanueva Francisco Javier 308200430

-------

Solo se debe compilar el archivo Main.java el cual contiene el m�todo main.
Muy importante que los archivos taxis, choferes y due�os esten a la altura de src.

------

Se agrego la practica 3, a los correspondientes directorios.

------

Se agregaron los archivos de la pr�ctica 4, a los directorios correspondientes.

------

Se agregar�n los archivos de la pr�ctica 5, a los directorios correspondientes.

------

Pr�ctica 6

Se agrego el archivo, DDL.sql a la carpeta sql
Para correr este script, tan solo se debe seguir los siguientes pasos:
1. Abrir terminal de windows 
2. Posicionarse en el directorio sql
3. Usar el comando sqlcmd -i DDL.sql
4. La base de datos se creara ya que todo esta incluido dentro del script.

-------

Se agregar�n los archivos de la pr�ctica 7, tanto el reporte como los archivos 
modificados, estos se especifican en el reporte.

-------

Se agregar�n los archivos de la pr�ctica 8, tanto el diagrama ya normalizado como el reporte
el cual contiene la forma en que se normalizo las relaciones.

Ya que no se pod�a ingresar a la p�gina donde se especifica el nombre que deb�an llevar los archivos,
El nuevo modelo relacional normalizado aparece como, Practica08.vpp
y el reporte esta nombrado como, Reporte - Practica08.pdf