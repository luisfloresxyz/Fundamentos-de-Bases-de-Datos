Jaime Daniel Garc�a Argueta 312104739
Flores Gonz�lez Luis Brandon 312218342

-------

Solo se debe compilar el archivo Main.java el cual contiene el m�todo main.
Muy importante que los archivos taxis, choferes y due�os esten a la altura de src.

------

Se agrego la practica 3, a los correspondientes directorios.

------

Se agregaron los archivos de la pr�ctica 4, a los directorios correspondientes.

------

Se agregar�n los archivos de la pr�ctica 5, a los directorios correspondientes.

------

Pr�ctica 6

Se agrego el archivo, DDL.sql a la carpeta sql
Para correr este script, tan solo se debe seguir los siguientes pasos:
1. Abrir terminal de windows 
2. Posicionarse en el directorio sql
3. Usar el comando sqlcmd -i DDL.sql
4. La base de datos se creara ya que todo esta incluido dentro del script.

-------

Se agregar�n los archivos de la pr�ctica 7, tanto el reporte como los archivos 
modificados, estos se especifican en el reporte.

-------

Se agregar�n los archivos de la pr�ctica 8, tanto el diagrama ya normalizado como el reporte
el cual contiene la forma en que se normalizo las relaciones.

Ya que no se pod�a ingresar a la p�gina donde se especifica el nombre que deb�an llevar los archivos,
El nuevo modelo relacional normalizado aparece como, Practica08.vpp
y el reporte esta nombrado como, Reporte - Practica08.pdf

--------

Pr�ctica 9

Se agregar�n los archivos correspondientes a la pr�ctica: Diccionario de Datos.pdf,
DDL.sql y reporte - practica 9.pdf

Las instrucciones para correr el DDL.sql son las mismas que las que se indicar�n en la
pr�ctica 6.

Todo biene bien detallado en el reporte.

----------

Pr�ctica 10

Se agregar�n los archivos correspondientes a la pr�ctica: Reporte-practica10 y DML.sql

En el reporte - practica 10.pdf viene la especificaci�n.

-----

Pr�ctica 11

Se agregar�n los archivos correspondientes a la pr�ctica: Reporte-practica11 y consultas.sql. Este ultimo se encuentra 
en la carpeta sql.

En el reporte - practica 11.pdf viene la especificaci�n.

-----

Pr�ctica 12

Se agregar�n los archivos correspondientes a la pr�ctica: Reporte-practica12 y la carpeta de Netbeans para poder ejecutar 
el sitio de Internet, esta esta dentro de src con el nombre de BD-Practica12-V2.

En el reporte - practica 12.pdf viene la especificaci�n y forma de compilar.

----
Pr�ctica 13

La localizaci�n de los archivos y la especificacion de las consultas que se realizar�n estan en el reporte Reporte-Practica13.pdf que se encuentra
en el directorio doc.

Pero se siguier�n las especificaciones para ordenar los archivos por lo que no deber�a haber mayor problema.
